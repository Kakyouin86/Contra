﻿using System;
using MoreMountains.Feedbacks;
using MoreMountains.Tools;
using UnityEngine;

namespace MoreMountains.CorgiEngine
{
	/// <summary>
	/// Add this class to a collider (2D or 3D) and it'll let you trigger things after a duration, like a mine would.
	/// It also comes with options to interrupt or reset the timer on exit. 
	/// </summary>
	public class ProximityMine : CorgiMonoBehaviour
	{
		[Header("Proximity Mine")]
		/// the layers that will trigger this mine
		[Tooltip("the layers that will trigger this mine")]
		public LayerMask TargetLayerMask;
		/// whether or not to disable the mine when it triggers/explodes
		[Tooltip("whether or not to disable the mine when it triggers/explodes")]
		public bool DisableMineOnTrigger = true;

		[Header("WarningDuration")] 
		/// the duration of the warning phase, in seconds, betfore the mine triggers
		[Tooltip("the duration of the warning phase, in seconds, betfore the mine triggers")]
		public float WarningDuration = 2f;
		/// whether or not the warning should stop when exiting the zone
		[Tooltip("whether or not the warning should stop when exiting the zone")]
		public bool WarningStopsOnExit = false;
		/// whether or not the warning duration should reset when exiting the zone
		[Tooltip("whether or not the warning duration should reset when exiting the zone")]
		public bool WarningDurationResetsOnExit = false;

		/// a read only display of the current duration before explosion
		[Tooltip("a read only display of the current duration before explosion")]
		[MMReadOnly] 
		public float TimeLeftBeforeTrigger;
        
		[Header("Feedbacks")]
		/// the feedback to play when the warning phase starts
		[Tooltip("the feedback to play when the warning phase starts")]
		public MMFeedbacks OnWarningStartsFeedbacks;
		/// a feedback to play when the warning phase stops
		[Tooltip("a feedback to play when the warning phase stops")] 
		public MMFeedbacks OnWarningStopsFeedbacks;
		/// a feedback to play when the warning phase is reset
		[Tooltip("a feedback to play when the warning phase is reset")] 
		public MMFeedbacks OnWarningResetFeedbacks;
		/// a feedback to play when the mine triggers
		[Tooltip("a feedback to play when the mine triggers")]
		public MMFeedbacks OnMineTriggerFeedbacks;
        
		protected bool _inside = false;
		protected Collider2D _collider;
		protected bool _canExplode = true;
		protected AutoRespawn _autoRespawn;
        
		/// <summary>
		/// On Start we initialize our mine
		/// </summary>
		protected virtual void Start()
		{
			Initialization();
		}

		/// <summary>
		/// On init we initialize our feedbacks and duration
		/// </summary>
		public virtual void Initialization()
		{
			_autoRespawn = this.gameObject.GetComponent<AutoRespawn>();
			_collider = this.gameObject.GetComponent<Collider2D>();
			OnWarningStartsFeedbacks?.Initialization();
			OnWarningStopsFeedbacks?.Initialization();
			OnWarningResetFeedbacks?.Initialization();
			OnMineTriggerFeedbacks?.Initialization();
			TimeLeftBeforeTrigger = WarningDuration;
		}

		protected void OnEnable()
		{
			TimeLeftBeforeTrigger = WarningDuration;
			_canExplode = true;
			_inside = false;
		}

		/// <summary>
		/// When colliding, we start our timer if needed
		/// </summary>
		/// <param name="collider"></param>
		protected virtual void Colliding(GameObject collider)
		{
			if (!MMLayers.LayerInLayerMask(collider.layer, TargetLayerMask))
			{
				return;
			}

			_inside = true;
            
			OnWarningStartsFeedbacks?.PlayFeedbacks();
		}

		/// <summary>
		/// When exiting, we stop our timer if needed
		/// </summary>
		/// <param name="collider"></param>
		protected virtual void Exiting(GameObject collider)
		{
			if (!MMLayers.LayerInLayerMask(collider.layer, TargetLayerMask))
			{
				return;
			}

			if (!WarningStopsOnExit)
			{
				return;
			}
            
			OnWarningStopsFeedbacks?.PlayFeedbacks();

			if (WarningDurationResetsOnExit)
			{
				OnWarningResetFeedbacks?.PlayFeedbacks();
				TimeLeftBeforeTrigger = WarningDuration;
			}
            
			_inside = false;
		}

		/// <summary>
		/// Describes what happens when the mine explodes
		/// </summary>
		public virtual void TriggerMine()
		{
			_canExplode = false;
			
			OnMineTriggerFeedbacks?.PlayFeedbacks();
            
			if (DisableMineOnTrigger)
			{
				_collider.enabled = false;
			}
			
			_autoRespawn?.Kill();
		}

		/// <summary>
		/// On Update if a target is inside the zone, we update our timer
		/// </summary>
		protected virtual void Update()
		{
			if (_inside)
			{
				TimeLeftBeforeTrigger -= Time.deltaTime;
			}

			if (_canExplode && TimeLeftBeforeTrigger <= 0)
			{
				TriggerMine();
			}
		}
        
		/// <summary>
		/// When a collision with the player is triggered, we give damage to the player and knock it back
		/// </summary>
		/// <param name="collider">what's colliding with the object.</param>
		public virtual void OnTriggerStay2D(Collider2D collider)
		{
			Colliding(collider.gameObject);
		}

		/// <summary>
		/// On trigger enter 2D, we call our colliding endpoint
		/// </summary>
		/// <param name="collider"></param>S
		public virtual void OnTriggerEnter2D(Collider2D collider)
		{
			Colliding(collider.gameObject);
		}

		/// <summary>
		/// On trigger enter 2D, we call our colliding endpoint
		/// </summary>
		/// <param name="collider"></param>S
		public virtual void OnTriggerExit2D(Collider2D collider)
		{
			Exiting(collider.gameObject);
		}
	}    
}